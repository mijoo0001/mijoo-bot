/* command registry */
require('./admin.js')
require('./audit')
require('./card.js')
require('./misc.js')
require('./user.js')
require('./tag.js')
require('./guild.js')
require('./auction.js')
require('./store.js')
require('./smith.js')
require('./hero.js')
require('./transaction.js')
require('./collection.js')
require('./preferences.js')
require('./meta.js')
require('./plot.js')

module.exports = {}

module.exports = {
    red: 14356753,
    yellow: 16756480,
    green: 1030733,
    blue: 1420012,
    grey: 3553598,
    deepgreen:1142316,
    default: 2067276
}

var sharedArray = [];
module.exports = sharedArray;